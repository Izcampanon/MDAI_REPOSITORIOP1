# ENTRADA**X**PRESS
## LOGO
![Logo de Markdown](https://i.pinimg.com/736x/7e/4d/13/7e4d13abe172e3c7dc602defb289e2ca.jpg)
### INTEGRANTES
- Izan Campanon Lopez //DNI: 80103976J
  ![Foto izan]()
- Lucia Gil Corrales //DNI: 77027423D
  ![Foto lucia]("C:\Users\izanc\Downloads\demo\demo\src\main\java\com\example\demo\Imagen Lucia.png")
### ESLOGAN
La fiesta no espera, asegura tu entrada hoy
### RESUMEN
EntradasXpress permite comprar entradas para fiestas de manera rápida y segura, consultar toda la información del evento y recibir notificaciones. Genera entradas digitales listas para mostrar en el acceso, ofreciendo comodidad y organización desde la compra hasta la asistencia.
#### DESCRIPCION
La aplicación permite a los usuarios comprar entradas de manera rápida y segura para fiestas y eventos. Ofrece una interfaz intuitiva donde los asistentes pueden consultar fechas, horarios, ubicación y tipos de entradas disponibles. Además, permite el pago en línea mediante diversos métodos y genera un código de entrada digital que se puede mostrar en el acceso al evento. La app también notifica a los usuarios sobre promociones, cambios de horario o eventos relacionados, asegurando una experiencia cómoda y organizada desde la compra hasta la asistencia a la fiesta.
#### FUNCIONALIDADES Y REQUISITOS
* El usuario debe poder seleccionar el evento al que desea asistir.

* El usuario debe poder cambiar o eliminar el evento seleccionado.

* Los resultados de la búsqueda se mostrarán agrupados primero por eventos próximos y luego por eventos futuros o relacionados.

* La interacción con los resultados de la búsqueda deriva en dos casos:

  * Si el usuario selecciona un evento, se inicia el proceso de compra de entradas.

  * Si el usuario selecciona un artista o lugar, se muestran los eventos disponibles relacionados.

* El proceso de compra conecta con pasarelas de pago seguras.

* El usuario puede seleccionar el tipo y cantidad de entradas.

* La entrada generada será digital y editable por el usuario (por ejemplo, modificar cantidad o tipo de entrada antes de finalizar la compra).

* El usuario debe ver todas las entradas que ha comprado y su estado (disponible, utilizada, cancelada).

* El usuario debe recibir notificaciones sobre cambios en los eventos, promociones o recordatorios.

* El usuario debe poder consultar la información detallada del evento, como fecha, hora, ubicación y disponibilidad de entradas.

#### FUNCIONALIDADES OPCIONALES

* La búsqueda puede ser por nombre del evento, artista o lugar.

* La aplicación web y móvil puede ser utilizada desde PC y dispositivos móviles, por tanto, debe adaptarse al dispositivo.

* El usuario debe poder ver una lista de eventos recomendados generada aleatoriamente, basada en sus compras o interacciones anteriores.

* El usuario debe poder elegir el idioma de la interfaz de la aplicación.

* En el proceso de generación de la entrada digital, incluir mensajes promocionales, enlaces a ofertas o paquetes especiales, imágenes del establecimiento/evento y descuentos disponibles.