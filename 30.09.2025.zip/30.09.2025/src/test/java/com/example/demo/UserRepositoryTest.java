package com.example.demo;

import com.example.demo.data.model.model.User;
import com.example.demo.data.model.repository.UserRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class UserRepositoryTest {

    @Autowired
    private UserRepository userRepository;

     @Test
    void findUserName(){
         userRepository.deleteAll(); // Limpiar la base de datos antes del test
         User user = new User("John", "john@alumnos.unex.es"); // usuario creado
         User savedUser = userRepository.save(user); // usuario guardado en la base de datos
         User fetchedUser = userRepository.findById(savedUser.getId()).orElse(null); // usuario recuperado de la base de datos
         Assertions.assertNotNull(fetchedUser); // comprobamos que el usuario no es nulo
         Assertions.assertEquals("John", fetchedUser.getName()); // comprobamos el nombre
         Assertions.assertEquals("john@alumnos.unex.es", fetchedUser.getEmail()); // comprobamos el email
     }

}
