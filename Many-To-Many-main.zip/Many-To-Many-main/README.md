# Many-To-Many Bidirectional
MDAI many to many bidirectional public example.
