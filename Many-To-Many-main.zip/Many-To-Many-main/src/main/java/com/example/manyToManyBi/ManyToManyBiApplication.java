package com.example.manyToManyBi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManyToManyBiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManyToManyBiApplication.class, args);
	}

}
